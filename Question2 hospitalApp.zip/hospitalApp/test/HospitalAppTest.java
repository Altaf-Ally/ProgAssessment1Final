/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */


import hospitalapp.HospitalApp;
import hospitalapp.Patient;
import hospitalapp.PatientCount;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author altaafally
 */
public class HospitalAppTest {
    
    public HospitalAppTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    
    @Test
   public void testAddPatient() {
        HospitalApp hospitalApp = new HospitalApp();
        Patient patient1 = new Patient("John Doe", 35, "P001", "Fever");
        Patient patient2 = new Patient("Mary Johnson", 42, "P002", "Headache");
        hospitalApp.addPatient(patient1);
        hospitalApp.addPatient(patient2);

        assertEquals(2, PatientCount.getPatientCount());
    }

    @Test
   public void testDisplayPatientRecords() {
        HospitalApp hospitalApp = new HospitalApp();
        Patient patient1 = new Patient("John Doe", 35, "P001", "Fever");
        Patient patient2 = new Patient("Mary Johnson", 42, "P002", "Headache");
        hospitalApp.addPatient(patient1);
        hospitalApp.addPatient(patient2);

        // Assuming proper console output format, we cannot assert the console output directly.

        // Testing the patient count
        assertEquals(2, PatientCount.getPatientCount());
   }  
        
    @Test
    public void testAddPatient_MaximumLimit() {
        HospitalApp hospitalApp = new HospitalApp();

        // Adding patients up to the maximum limit
        for (int i = 0; i < HospitalApp.MAX_PATIENTS; i++) {
            Patient patient = new Patient("Patient " + i, 30 + i, "P00" + (i + 1), "Some Condition");
            hospitalApp.addPatient(patient);
        }

        // Attempting to add one more patient beyond the limit
        Patient extraPatient = new Patient("Extra Patient", 40, "P011", "Some Condition");
        hospitalApp.addPatient(extraPatient);

        assertEquals(PatientCount.getPatientCount, PatientCount.getPatientCount());
    }

    @Test
    public void testDisplayPatientRecords_EmptyRecords() {
        var hospitalApp = new HospitalApp();
        hospitalApp.displayPatientRecords();  // Display patient records when no patients added
        // Assuming proper console output format, we cannot assert the console output directly.
        assertEquals(2, PatientCount.getPatientCount());
    }

    @Test
    public void testDisplayPatientRecords_NonEmptyRecords() {
        HospitalApp hospitalApp = new HospitalApp();
        Patient patient1 = new Patient("John kane", 35, "P001", "Fever");
        Patient patient2 = new Patient("Mary Johnson", 42, "P002", "Headache");
        hospitalApp.addPatient(patient1);
        hospitalApp.addPatient(patient2);

        // Assuming proper console output format, we cannot assert the console output directly.

        // Testing the patient count
        assertEquals(2, PatientCount.getPatientCount());
    }
}

