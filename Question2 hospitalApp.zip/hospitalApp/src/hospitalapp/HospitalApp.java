/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hospitalapp;

/**
 *
 * @author altaafally
 */
public class HospitalApp {
    public static int MAX_PATIENTS = 10;
    public Patient[] patients = new Patient[MAX_PATIENTS];
    public int patientCount = 0;

    public void addPatient(Patient patient) {
        if (patientCount < MAX_PATIENTS) {
            patients[patientCount] = patient;
            patientCount++;
        } else {
            System.out.println("Maximum patient limit reached.");
        }
    }

    public void displayPatientRecords() {
        for (int i = 0; i < patientCount; i++) {
            System.out.println("Patient " + (i + 1) + " Details:");
            patients[i].displayInfo();
            System.out.println();
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HospitalApp hospitalApp = new HospitalApp();

        // Add patients
        hospitalApp.addPatient(new Patient("John Kane", 35, "P001", "Fever"));
        hospitalApp.addPatient(new Patient("Mary Johnson", 42, "P002", "Headache"));

        // Display patient records
        hospitalApp.displayPatientRecords();
        
      // Display patient count
        System.out.println("Total Patients: " + PatientCount.getPatientCount());

    }

    }

    

