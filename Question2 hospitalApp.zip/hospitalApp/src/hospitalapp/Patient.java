/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalapp;

/**
 *
 * @author altaafally
 */
public class Patient extends Person {
    public String patientID;
    public String diagnosis;

    public Patient(String name, int age, String patientID, String diagnosis) {
        super(name, age);
        this.patientID = patientID;
        this.diagnosis = diagnosis;
    
    }
    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Patient ID: " + patientID);
        System.out.println("Diagnosis: " + diagnosis);
    }
}
    
    
    

