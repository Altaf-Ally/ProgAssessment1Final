/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalapp;

/**
 *
 * @author altaafally
 */
public class PatientCount {

    public static int getPatientCount = 2;

    public static void incrementCount() {
        getPatientCount++;
    }

    public static int getPatientCount() {
        return getPatientCount;
    }
}


