/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package progassessment1;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author altaafally
 */
public class StudentTest {
    
    public StudentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }


    @Test
    public void testSearchStudent() {
        // Create some students
        Student student1 = new Student(1, "Alice", 20, "alice@example.com", "Computer Science");
        Student student2 = new Student(2, "Bob", 18, "bob@example.com", "Mathematics");
        Student student3 = new Student(3, "Charlie", 22, "charlie@example.com", "Physics");

        ArrayList<Student> students = new ArrayList<>();
        students.add(student1);
        students.add(student2);
        students.add(student3);

        // Search for a student
        Student foundStudent = student1.searchStudent(students, 1);
        assertEquals(student1, foundStudent);

        // Search for a non-existing student
        foundStudent = student1.searchStudent(students, 5);
        assertNull(foundStudent);
    }

    @Test
    public void testDeleteStudent() {
        // Create some students
        Student student1 = new Student(1, "Alice", 20, "alice@example.com", "Computer Science");
        Student student2 = new Student(2, "Bob", 18, "bob@example.com", "Mathematics");
        Student student3 = new Student(3, "Charlie", 22, "charlie@example.com", "Physics");

        ArrayList<Student> students = new ArrayList<>();
        students.add(student1);
        students.add(student2);
        students.add(student3);

        // Delete an existing student
        student1.deleteStudent(students, 1);
        assertEquals(2, students.size());

        // Try to delete a non-existing student
        student1.deleteStudent(students, 5);
        assertEquals(2, students.size());
        
    }
    @Test
    public void testStudentInequality() {
        Student student1 = new Student(1, "Alice", 20, "alice@example.com", "Math");
        Student student2 = new Student(2, "Bob", 21, "bob@example.com", "Science");

        assertNotEquals(student1, student2);
}
}

    
    

