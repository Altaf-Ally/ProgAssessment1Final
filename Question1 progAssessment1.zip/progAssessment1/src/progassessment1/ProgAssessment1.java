/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progassessment1;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author altaafally
 */
public class ProgAssessment1 
 {
   private static final ArrayList<Student> students = new ArrayList<>();
   private static int studentIDCounter = 1;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Menu();
    }

          
   //Allows user to make a choice in the program
       public static void Menu()
       {
        while (true)
        {
            String menuMessage = "STUDENT MANAGEMENT APPLICATION\n" + "*******************************************" +
                    "\nEnter (1) to launch menu or any other key to exit";

            String userInput = JOptionPane.showInputDialog(menuMessage);

            if (userInput == null || !userInput.equals("1"))
            {
                JOptionPane.showMessageDialog(null, "Exiting the application.");
                System.exit(0);
            }

            String[] options = {"Capture a new student", "Search for a student", "Delete a student", "Print student report", "Exit Application"};
            int choice = JOptionPane.showOptionDialog(null, "Student Management System", "Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            Student student = new Student(0, "", 0, "", ""); // Create a new student

            switch (choice)
            {
                case 0:
                    student.SaveStudent(studentIDCounter++, student);
                    students.add(student);
                    break;
                case 1:
                    searchStudent();
                    break;
                case 2:
                    deleteStudent();
                    break;
                case 3:
                    viewStudentReport();
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Exiting the application.");
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
            }
        }
    }

   
   
    public static void searchStudent()
    {
        int searchID;
        try
        {
            searchID = Integer.parseInt(JOptionPane.showInputDialog("Enter the student id to search:"));
        } catch (NumberFormatException e)
        {
            JOptionPane.showMessageDialog(null, "Invalid input for student ID. Please enter a number.");
            return;
        }

        Student foundStudent = new Student(0, "", 0, "", "").searchStudent(students, searchID);
        if (foundStudent != null) {
            JOptionPane.showMessageDialog(null, "STUDENT ID: " + foundStudent.getStudentID() + "\n" +
                    "STUDENT NAME: " + foundStudent.getStudentName() + "\n" +
                    "STUDENT AGE: " + foundStudent.getStudentAge() + "\n" +
                    "STUDENT EMAIL: " + foundStudent.getStudentEmail() + "\n" +
                    "STUDENT COURSE: " + foundStudent.getStudentCourse());
        } else
        {
            JOptionPane.showMessageDialog(null, "Student with Student ID: " + searchID + " was not found!");
        }
    }

   
   
    public static void deleteStudent()
    {
        int deleteID;
        try {
            deleteID = Integer.parseInt(JOptionPane.showInputDialog("Enter the student id to delete:"));
        } catch (NumberFormatException e)
        {
            JOptionPane.showMessageDialog(null, "Invalid input for student ID. Please enter a number.");
            return;
        }

        new Student(0, "", 0, "", "").deleteStudent(students, deleteID);
    }

    public static void viewStudentReport()
    {
        String report = new Student(0, "", 0, "", "").viewStudentReport(students);
        JOptionPane.showMessageDialog(null, report);

        
    }
    
}

    
    

